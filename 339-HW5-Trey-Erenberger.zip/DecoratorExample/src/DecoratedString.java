/**
 * 
 */

/**
 * @author Trey
 *
 */
public interface DecoratedString {
	String getText();
	void print();
	void dosPrint();

}
